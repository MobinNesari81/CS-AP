
import com.company.inheritance.MusicalInstrument;

public class Piano extends MusicalInstrument {
    private String model;
    //Digital or acoustic
    private String type;
    private boolean woodenKeys;
    private double width;
    private double height;
    private double depth;
    private int numberOfKeys;
    private int numberOfPedals;

    public Piano(){
        System.out.println("New Object from Piano class has been created!");
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setDepth(double depth) {
        this.depth = depth;
    }

    public void setWidth(double width){
        this.width = width;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public void setNumberOfPedals(int numberOfPedals) {
        this.numberOfPedals = numberOfPedals;
    }

    public void setNumberOfKeys(int numberOfKeys) {
        this.numberOfKeys = numberOfKeys;
    }

    public void setWoodenKeys(boolean woodenKeys) {
        this.woodenKeys = woodenKeys;
    }

    public void setModel(String model){
        this.model = model;
    }

    public String getModel(){
        return this.model;
    }

    public String getType(){
        return this.type;
    }

    public boolean getWoodenKeys(){
        return this.woodenKeys;
    }

    public double getWidth(){
        return this.width;
    }

    public double getHeight(){
        return this.height;
    }

    public double getDepth(){
        return this.depth;
    }

    public int getNumberOfKeys(){
        return this.numberOfKeys;
    }

    public int getNumberOfPedals(){
        return this.numberOfPedals;
    }

    public void setSize() {
        this.size = Double.toString(this.width) + " x " + Double.toString(this.height) + " x " + Double.toString(this.depth);
    }

    @Override
    public String toString(){
        String str = "Price : " + getPrice() + " Quantity : " + getQuantity() + " DateAdded : " + getDateAdded() + " Seller Company : "
                + getSellerCompany() + " Brand: " + getBrand() + " Material : " + getMaterial() + " Weight : " + getWeight() + " color : "
                + getColor() + " Sales Unit : " + getSalesUnit() + " Type : " + getType() + " Model : " + getModel() + " Width : " + getWidth()
                + " Height : " + getHeight() + " Depth : " + getDepth() + " Wooden Keys: " + getWoodenKeys() + " # of Pedals : " + getNumberOfPedals()
                + " # of Keys : " + getNumberOfKeys();
        return str;
    }
}
