
public class MusicalInstrument extends Product {
    private String material;
    private  double weight;
    private String color;
    private int salesUnit;

    public MusicalInstrument(){
        System.out.println("New Object from MusicalInstrument class has been created!");
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public void setSalesUnit(int salesUnit) {
        this.salesUnit = salesUnit;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMaterial() {
        return material;
    }

    public double getWeight() {
        return weight;
    }

    public String getColor() {
        return color;
    }
    // overload (method with the same name but different arguments)
    public int getSalesUnit(){
        return this.salesUnit;
    }

    @Override
    public String toString(){
        String str = "Price : " + getPrice() + " Quantity : " + getQuantity() + " DateAdded : " + getDateAdded() + " Seller Company : "
                + getSellerCompany() + " Brand: " + getBrand() + " Material : " + getMaterial() + " Weight : " + getWeight() + " color : "
                + getColor() + " Sales Unit : " + getSalesUnit();
        return str;
    }
}
