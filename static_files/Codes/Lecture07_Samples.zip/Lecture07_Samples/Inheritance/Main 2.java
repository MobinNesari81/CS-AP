import java.util.ArrayList;
import java.util.Date;

public class Main {

    public static void main(String[] args) {
        ArrayList<Product> products = new ArrayList<>();
        ArrayList<MusicalInstrument> musicalInstruments = new ArrayList<>();
        ArrayList<Piano> pianos = new ArrayList<>();
        Product product = new Product();
        product.setBrand("iPhone");
        product.setPrice(1000);
        product.setSize("15 x 7.5");
        Date date = new Date();
        product.setDateAdded(date);
        product.setQuantity(30);
        product.setSellerCompany("Apple");
        String str = product.toString();
        System.out.println(str);
        products.add(product);
        // It's not considered as children class so CANNOT be added to pianos arraylist
        // pianos.add(product);

        Piano piano = new Piano();
        piano.setBrand("Yamaha");
        piano.setSellerCompany("Yamaha");
        piano.setPrice(1225.00);
        piano.setWidth(1.357);
        piano.setHeight(849);
        piano.setDepth(422);
        piano.setMaterial("Wood");
        piano.setColor("white");
        piano.setSalesUnit(1);
        piano.setDateAdded(date);
        piano.setQuantity(20);
        piano.setWeight(42.0);
        piano.setModel("ydp165");
        piano.setType("Digital");
        piano.setWoodenKeys(true);
        piano.setNumberOfKeys(88);
        piano.setNumberOfPedals(3);
        str = piano.toString();
        System.out.println(str);
        pianos.add(piano);
        products.add(piano);
        musicalInstruments.add(piano);

        // You can have new obj with special class type and then new it from any of its children.
        Product productPiano = new Piano();
        productPiano.setBrand("Kawai");
        productPiano.setPrice(1100);
        productPiano.setSize("15 x 7.5");
        productPiano.setDateAdded(date);
        productPiano.setQuantity(55);
        productPiano.setSellerCompany("Kawai");
        String str1 = product.toString();
        products.add(productPiano);
        // productPiano obj datatype is Product, so it CAN'T be added to a arraylist with Piano class datatype.
       // pianos.add(productPiano);
        
        // U don't have access to Piano's class attributes and methods despite the fact that you initialize this obj from this class.
        // Because the datatype of this obj is Product. Super class doesn't have access to its subclasses attributes and methods.
       // productPiano.setWoodenKeys(false);
        System.out.println(str1);
        // We don't have access to attributes and metods available on Piano class. Because productPiano datatype is Product class
        // You cannot initialize the obj from parent class
        // Piano piano1 = new Product();







    }


}
