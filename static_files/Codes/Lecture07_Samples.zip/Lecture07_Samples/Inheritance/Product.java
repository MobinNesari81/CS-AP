
import java.util.Date;

public class Product {
    private double price;
    private int quantity;
    private Date dateAdded;
    private String sellerCompany;
    private String brand;
    String size;

    public Product(){
        System.out.println("New Object from Product class has been created!");
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setDateAdded(Date dateAdded) {
        this.dateAdded = dateAdded;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setSellerCompany(String sellerCompany) {
        this.sellerCompany = sellerCompany;
    }

    public double getPrice() {
        return price;
    }

    public String getBrand() {
        return brand;
    }

    public Date getDateAdded() {
        return dateAdded;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getSellerCompany() {
        return sellerCompany;
    }

    public void setSize(String size){
        this.size = size;
    }

    @Override
    public String toString(){
        String str = "Price : " + getPrice() + " Quantity : " + getQuantity() + " DateAdded : " + getDateAdded() + " Seller Company : "
                + getSellerCompany() + " Brand: " + getBrand();
        return str;
    }
}
