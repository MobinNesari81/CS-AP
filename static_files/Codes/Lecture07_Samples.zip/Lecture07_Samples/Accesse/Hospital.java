
import javax.swing.*;
import java.util.ArrayList;

public class Hospital {
    protected ArrayList<Room> rooms = new ArrayList<>();
    protected ArrayList<Nurse> nurses = new ArrayList<>();
    protected ArrayList<Specialist> specialists = new ArrayList<>();
    protected ArrayList<Patient> patients = new ArrayList<>();
    protected ArrayList<Surgery> surgeryHistory = new ArrayList<>();

    protected void addRoom(Room room){
        this.rooms.add(room);
    }

    protected void removeRoom(Room room){
        this.rooms.remove(room);
    }

    protected void addNurse(Nurse nurse){
        this.nurses.add(nurse);
    }
    protected void removeNurse(Nurse nurse){
        this.nurses.remove(nurse);
    }

    protected void addSpecialist(Specialist specialist){
        this.specialists.add(specialist);
    }

    protected void removeSpecialist(Specialist specialist){
        this.specialists.remove(specialist);
    }

    protected void addPatient(Patient patient){
        this.patients.add(patient);
    }
    protected void removePatient(Patient patient){
        this.patients.remove(patient);
    }

    protected void addToSurgeryHistory(Surgery surgery){
        this.surgeryHistory.add(surgery);
    }

}
