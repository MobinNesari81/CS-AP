import java.util.Date;

public class Main {
    public static void main(String[] args) {
        Hospital hospital = new Hospital();
        Room room = new Room();
        room.setRoomNumber("101");
        Nurse nurse = new Nurse();
        nurse.setName("Ava Schiller");
        nurse.setId("ava_schiller");
        Specialist specialist = new Specialist();
        specialist.setName("Bruno Schneider");
        specialist.setId("bruno_schneider");
        Patient patient = new Patient();
        patient.setName("Sara Bahman");
        patient.setPersonalSpecialist(specialist);
        patient.setId("sara_bahman");
        hospital.addNurse(nurse);
        hospital.addRoom(room);
        hospital.addSpecialist(specialist);
        hospital.addPatient(patient);
        Surgery surgery = new Surgery();
        Date date = new Date();
        surgery.setDate(date);
        surgery.setRoom(room);
        surgery.setSpecialist(specialist);
        surgery.addThisSurgery(hospital);
        for (Room room1 : hospital.rooms){
            System.out.println(room1.toString());
        }
        for (Patient patient1 : hospital.patients){
            System.out.println(patient1.toString());
        }

        for (Specialist specialist1 : hospital.specialists){
            System.out.println(specialist1.toString());
        }

        for (Nurse nurse1 : hospital.nurses){
            System.out.println(nurse1.toString());
        }

        System.out.println("Surgery History");
        
        for (Surgery surgery1 : hospital.surgeryHistory){
            System.out.println(surgery1.toString());
        }

    }
}
