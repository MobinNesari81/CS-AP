
public class Specialist {
    private String name;
    private String id;

    public void setName(String name) {
        this.name = name;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    @Override
    public String toString(){
        String str = "Specialist Name : " + this.getName() + " Specialist ID : " + this.getId();
        return str;
    }
}
