
public class Patient {
    private String name;
    private String id;
    private Specialist personalSpecialist;

    public void setName(String name) {
        this.name = name;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public void setPersonalSpecialist(Specialist personalSpecialist) {
        this.personalSpecialist = personalSpecialist;
    }

    public Specialist getPersonalSpecialist() {
        return personalSpecialist;
    }

    @Override
    public String toString(){
        String str = "Patient Name : " + this.getName() + " Specialist ID : " + this.getId() +
                " Personal Specialist Info : " + this.getPersonalSpecialist().toString();
        return str;
    }
}
