
import java.util.Date;
// Classes cannot extend from final classes. By defining Surgery class final,
// we make sure no one can extend it.
public final class Surgery extends Hospital{
    protected Room room;
    protected Date date;
    protected Specialist specialist;


    public void setRoom(Room room) {
        this.room = room;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setSpecialist(Specialist specialist) {
        this.specialist = specialist;
    }

    public Room getRoom() {
        return room;
    }

    public Date getDate() {
        return date;
    }

    public Specialist getSpecialist() {
        return specialist;
    }

    public void addThisSurgery(Hospital hospital){
        hospital.addToSurgeryHistory(this);
    }

    @Override
    public String toString(){
        String str = "Surgery room : " + this.getRoom().toString() + " Surgery Date : " + this.getDate() +
                " Sugery Specialist Info : " + this.getSpecialist().toString();
        return  str;
    }
}
