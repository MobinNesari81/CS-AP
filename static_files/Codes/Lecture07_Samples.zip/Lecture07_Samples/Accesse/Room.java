
public class Room{
    private String roomNumber;

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    @Override
    public String toString(){
        String str = "Room number : " + this.getRoomNumber();
        return str;
    }
}
