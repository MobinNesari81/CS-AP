
import java.util.UUID;

public class User extends JsonFormat{

    public String loginToJsonFormat() {
        return super.loginToJsonFormat(this.getEntranceCode(), this.getPassword());
    }

    private String userId;
    private String password;

    public void setUserId() {
        UUID uuid = UUID.randomUUID();
        this.userId = uuid.toString();
    }


    public String getUserId() {
        return userId;
    }
}
