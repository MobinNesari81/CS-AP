public class Main {
    public static void main(String[] args) {
        Json json = new Json() {
            @Override
            public String loginToJsonFormat(String entranceCode, String password) {
                return null;
            }
        };
        // This loginToJsonFormat method returns null because doesn't have body in Json class.
        System.out.println(json.loginToJsonFormat("entrance_code_json", "@1234"));
        // This loginToJsonFormat method returns Json String Format. What we wrote in its body in JsonFormat Class.
        JsonFormat jsonFormat = new JsonFormat() {
            @Override
            public String loginToJsonFormat(String entranceCode, String password) {
                return super.loginToJsonFormat(entranceCode, password);
            }
        };
        System.out.println(jsonFormat.loginToJsonFormat("entrance_code_json_format", "@1234"));

        User user = new User();
        user.setUserId();
        user.setEntranceCode(user.getUserId());
        user.setPassword("#1234");
        System.out.println(user.loginToJsonFormat());

    }
}
