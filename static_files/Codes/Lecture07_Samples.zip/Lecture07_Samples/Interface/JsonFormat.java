// This class implements interface Json, if I don't override methods in interface,
// this class shows and error occurred because of not overriding interface methods.
// (Here we fill body of the method).
// So this means that if two class implements an interface,
// they can have different implementation for interface methods.
public abstract class JsonFormat implements Json {

    private String entranceCode;
    private String password;
    @Override
    public String loginToJsonFormat(String entranceCode, String password) {
        // For setting entranceCode and password you need to parse the JsonFormatString to JsonObj
        // then put key value you've gotten
        String jsonFormat = "{\"task\":\"login\",\"entranceCode\":\"" + entranceCode + "\",\"password\":\"" + password + "\"}";
        return jsonFormat;
    }

    public void setEntranceCode(String entranceCode) {
        this.entranceCode = entranceCode;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEntranceCode() {
        return entranceCode;
    }

    public String getPassword() {
        return password;
    }
}
