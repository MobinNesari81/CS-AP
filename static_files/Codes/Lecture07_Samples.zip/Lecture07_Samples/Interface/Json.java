// With this interface I make sure that any class implements this interface,
// have to override methods I have here.
public interface Json {
    public String loginToJsonFormat(String entranceCode, String password);
    // Methods in interfaces CAN'T have body.
}
